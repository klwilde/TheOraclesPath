async function sendMessage() {
    const inputField = document.getElementById("user-input");
    let userMessage = inputField.value.trim();
    if (!userMessage) return;
    
    const chatBox = document.getElementById("chat-box");
    chatBox.innerHTML += `<p><strong>You:</strong> ${userMessage}</p>`;
    inputField.value = "";
    
    try {
        let response = await fetch("/.netlify/functions/chatbot", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ message: userMessage })
        });

        if (!response.ok) throw new Error("API request failed");

        let data = await response.json();
        chatBox.innerHTML += `<p><strong>Oracle:</strong> ${data.response}</p>`;
    } catch (error) {
        console.error("Error fetching AI response:", error);
        chatBox.innerHTML += `<p><strong>Oracle:</strong> The void is silent...</p>`;
    }
}
